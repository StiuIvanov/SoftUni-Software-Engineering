package PizzaCalories;

import java.util.Locale;

public class Dough {
    private String flourType;
    private String bakingTechnique;
    private double weight;

    public Dough(String flourType, String bakingTechnique, double weight) {
        setFlourType(flourType);
        setBakingTechnique(bakingTechnique);
        setWeight(weight);
    }

    private void setWeight(double weight) {
        if (weight < 1 || weight > 200) {
            throw new IllegalArgumentException("Dough weight should be\n" +
                    "in the range [1..200].");
        }
        this.weight = weight;
    }

    private void setFlourType(String flourType){
       if (!isValidFlourType(flourType)){
           throw new IllegalArgumentException("Invalid\n" +
                   "type of dough.");
       }
       this.flourType = flourType;
    }

    private void  setBakingTechnique(String bakingTechnique){
        if (!isValidBakingTechnique(bakingTechnique)){
            throw new IllegalArgumentException("Invalid\n" +
                    "type of dough.");
        }
        this.bakingTechnique=bakingTechnique;
    }

    public double calculateCalories(){
        DoughModifier doughModifier = DoughModifier.valueOf(this.bakingTechnique.toUpperCase());
        double modifierBakingTechnique = doughModifier.getModifier();
        DoughModifier doughModifierFlourType = DoughModifier.valueOf(this.flourType.toUpperCase());
        double modifierFlourType = doughModifierFlourType.getModifier();

        return 2* weight*modifierFlourType*modifierBakingTechnique;
    }





    private boolean isValidBakingTechnique(String bakingTechnique) {
        return bakingTechnique.equals("Crispy") || bakingTechnique.equals("Chewy") ||
                bakingTechnique.equals("Homemade");
    }


    private boolean isValidFlourType(String flourType) {
        return flourType.equals("White") || flourType.equals("Wholegrain");
    }

}
