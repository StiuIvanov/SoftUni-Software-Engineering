package PizzaCalories;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        setToppingType(toppingType);
        setWeight(weight);
    }

    private void setToppingType(String toppingType) {
        validateToppingType(toppingType);
        this.toppingType = toppingType;
    }

    private void   setWeight(double weight){
        validateWeight(weight);
        this.weight=weight;
    }

    public double calculateCalories(){
        double modifier = ToppingModifier.valueOf(toppingType).getModifier();
        return weight*2*modifier;
    }





    private void validateWeight(double weight) {
        if (weight<1 || weight>50){
            throw new IllegalArgumentException("Topping type name}\n" +
                    "weight should be in the range [1..50].");
        }
    }


    private void validateToppingType(String toppingType) {
        if (!toppingType.equals("Meat") || !toppingType.equals("Veggies") ||
                !toppingType.equals("Cheese") || !toppingType.equals("Sauce")){
            throw new IllegalArgumentException("Cannot place {name of\n" +
                    "invalid argument} on top of your pizza.");
        }
    }
}
