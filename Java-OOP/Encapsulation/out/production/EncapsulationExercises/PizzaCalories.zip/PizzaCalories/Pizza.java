package PizzaCalories;

import java.util.ArrayList;
import java.util.List;

public class Pizza {
    private String name;
    private Dough dough;
    private List<Topping> toppings;

    public Pizza(String name, int numberOfToppings){
        validateNumberOfToppings(numberOfToppings);
        setName(name);
        this.toppings= new ArrayList<>();
    }

    private void setToppings(int toppings){

    }

    private void setName(String name){
        validateName(name);
        this.name=name;
    }

    public void setDough(Dough dought){
        this.dough =dought;
    }

    public String getName() {
        return name;
    }

    public void addTopping(Topping topping){
        this.toppings.add(topping);
    }

    public double getOverallCalories(){
        double doughCalories = dough.calculateCalories();
        double sumToppings = this.toppings.stream().mapToDouble(Topping::calculateCalories).sum();
        return sumToppings+doughCalories;
    }

    private void validateName(String name) {
        if (name==null || name.isEmpty() || name.length()>15){
            throw new IllegalArgumentException("Pizza name should be between 1 and 15 symbols.");
        }
    }


    private void validateNumberOfToppings(int numberOfToppings) {
        if (numberOfToppings<0 || numberOfToppings>10){
            throw new IllegalArgumentException("Number of toppings\n" +
                    "should be in range [0..10].");
        }
    }
}
