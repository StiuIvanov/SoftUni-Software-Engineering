package CardSuit;

public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}
