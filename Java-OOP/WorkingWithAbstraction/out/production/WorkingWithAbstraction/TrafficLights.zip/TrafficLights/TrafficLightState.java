package TrafficLights;

public enum TrafficLightState {
    RED,
    YELLOW,
    GREEN;

}
